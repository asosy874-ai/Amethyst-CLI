# Amethyst

**English** | [Русский](#русский)

---

## English

Amethyst is an unofficial YouTube Music client for the terminal: real playback
through `mpv`/PipeWire, album art in the terminal, synchronized lyrics, a queue
and playlists. Sign-in works **without Google Cloud Console**: Amethyst reads
cookies from your browser (like Kanon) or accepts headers copied from DevTools.

The interface is available in **English and Russian**. On first start Amethyst
detects the language from the system locale; you can switch it in the main menu
with `10. Language / Язык`. The choice is saved to `settings.json`.

### Features

- Track search via `ytmusicapi`.
- Playback through `mpv` (IPC): pause/resume, stop, next track, seeking.
- Album art:
  - kitty graphics protocol at high resolution (up to 1080×1080);
  - ANSI truecolor fallback for other terminals.
- Synchronized lyrics: LRCLIB → YouTube Music timings → plain lyrics.
- Playback queue and local playlists.
- Import playlists from your YouTube Music account after sign-in: the list is
  cached locally and tracks are loaded when you open or play a playlist.
- Shuffle playlists without repeats.
- Volume: 5% and 1% steps, mouse wheel support.
- Sign-in without Cloud Console:
  - automatic session discovery in Firefox/Chromium;
  - manual headers or `curl` pasted from the browser;
  - OAuth (optional, if you have a client id/secret).
- Bilingual UI: English and Russian.

### Installation

You need **Python 3.10+** and **mpv**; the installer handles everything else.
Run it as your regular user, **without `sudo`**.

```bash
cd amethyst
./install.sh
```

The installer:

1. creates a virtual environment in `~/.local/share/amethyst/venv`;
2. installs Python dependencies from `requirements.txt`;
3. copies the app to `~/.local/share/amethyst`;
4. adds the `Amethyst` command to `~/.local/bin` (and an `amethyst` symlink).

After that, from any terminal and any directory:

```bash
Amethyst
```

The player runs in the same terminal window. If `~/.local/bin` is not in
`PATH`, the installer prints the line to add to `~/.bashrc` or `~/.zshrc`.

To update, run `./install.sh` again from the project directory.

#### Arch Linux

```bash
sudo pacman -S mpv
```

#### Running without installing

If the dependencies are already installed system-wide:

```bash
python3 amethyst.py
```

### Signing in (menu option 8)

#### 1. Automatically from the browser

Sign in at <https://music.youtube.com> in Firefox or a Chromium-based browser,
then choose:

```
8 → 1
```

Amethyst finds the cookies, verifies the session with a read-only account
request and saves the headers for `ytmusicapi`. Playlists from your library are
imported automatically and appear under `7. Playlists`.

#### 2. Manually (like Kanon)

If automatic discovery does not work:

1. Open `music.youtube.com` and sign in.
2. F12 → Network → reload the page → choose the `browse` request.
3. Right-click → Copy → **Copy request headers** (or **Copy as cURL**).
4. Choose `8 → 2`, paste the text and finish with an empty line.

#### 3. OAuth (optional)

Option `8 → 3`. Requires a `client_id` and `client_secret` from Google Cloud
Console.

### Player controls

| Key | Action |
| --- | --- |
| `Space` | pause / resume |
| `n` | next track |
| `s` | stop and exit |
| `q` / `Esc` | exit |
| `+` / `=` | volume +5% |
| `-` / `_` | volume −5% |
| `]` / `[` | volume +1% / −1% |
| mouse wheel, `↑` / `↓` | volume |
| `←` / `→` | seek 5 seconds |

### Language

Language priority:

1. `AMETHYST_LANG` environment variable (`ru` or `en`);
2. `language` in `settings.json`;
3. system locale (`LC_ALL`, `LC_MESSAGES`, `LANG`);
4. English.

Examples:

```bash
AMETHYST_LANG=en Amethyst
AMETHYST_LANG=ru Amethyst
```

The language can also be changed at runtime: `10. Language / Язык`.

### Where data is stored

Code and user data are separated. Cookies, OAuth tokens and playlists live
outside the project directory:

```
Linux:   $XDG_CONFIG_HOME/amethyst   (~/.config/amethyst by default)
macOS:   ~/Library/Application Support/amethyst
Windows: %APPDATA%\amethyst
```

The path can be overridden with `AMETHYST_DATA_DIR`.

| File | Purpose |
| --- | --- |
| `browser_auth.json` | account cookies/headers (`600` permissions) |
| `oauth.json` | OAuth token (if used) |
| `oauth_client.json` | OAuth client id/secret (if used) |
| `playlists.json` | local playlists |
| `account_playlists.json` | cached list of account playlists |
| `settings.json` | UI language and other settings |

Legacy data from `~/.config/ytmusic-cli` is migrated automatically on start.
You can refresh the account playlist list with `7 → 7`. Tracks are loaded from
YouTube Music when you open or play a playlist.

For shuffle without repeats, choose `7 → 8. Play a playlist shuffled (no repeats)`.

> **Important:** `browser_auth.json` grants access to your account. Never
> publish or commit it — it is already excluded in `.gitignore`.

### Uninstall

```bash
./install.sh --uninstall          # remove the app, keep account data
./install.sh --uninstall --purge  # remove the app and account data
```

### Project layout

```
amethyst/
├── amethyst.py               # the whole player
├── install.sh                # installer and uninstaller
├── requirements.txt          # Python dependencies
├── README.md
├── .gitignore
├── amethyst-src.zip          # source archive
└── amethyst-src.tar.gz       # source archive
```

### Limitations

- This project is unofficial and not affiliated with Google/YouTube.
- `mpv`, `yt-dlp`, `ytmusicapi` and an active YouTube Music browser session are
  required.
- Some Chromium cookies are encrypted with a system key; Amethyst uses `yt-dlp`
  for those and falls back to manual headers if needed.

---

## Русский

Amethyst — неофициальный консольный клиент YouTube Music: реальное
воспроизведение через `mpv`/PipeWire, обложка в терминале, синхронизированный
текст, очередь и плейлисты. Вход в аккаунт работает **без Google Cloud
Console**: Amethyst забирает cookie из браузера (как Kanon) или принимает
заголовки, скопированные из DevTools.

Интерфейс доступен на **русском и английском**. При первом запуске Amethyst
определяет язык по системной локали; переключить его можно в главном меню
пунктом `10. Language / Язык`. Выбор сохраняется в `settings.json`.

### Возможности

- Поиск треков через `ytmusicapi`.
- Воспроизведение через `mpv` (IPC): пауза/продолжить, стоп, следующий трек,
  перемотка.
- Обложка альбома:
  - протокол kitty graphics с высоким разрешением (до 1080×1080);
  - ANSI truecolor fallback для других терминалов.
- Синхронизированный текст: LRCLIB → тайминги YouTube Music → обычный текст.
- Очередь воспроизведения и локальные плейлисты.
- Импорт плейлистов из аккаунта YouTube Music при входе: список сохраняется
  локально, треки подгружаются при открытии или воспроизведении плейлиста.
- Воспроизведение плейлиста в случайном порядке без повторов.
- Громкость: шаг 5% и 1%, управление колесом мыши.
- Вход в аккаунт без Cloud Console:
  - автопоиск сессии в Firefox/Chromium;
  - ручная вставка заголовков или `curl` из браузера;
  - OAuth (опционально, если есть client id/secret).
- Двуязычный интерфейс: русский и английский.

### Установка

Нужны **Python 3.10+** и **mpv**. Всё остальное установщик сделает сам.
Запускать его нужно от своего пользователя, **без `sudo`**.

```bash
cd amethyst
./install.sh
```

Установщик:

1. создаёт отдельное окружение в `~/.local/share/amethyst/venv`;
2. ставит Python-зависимости из `requirements.txt`;
3. копирует приложение в `~/.local/share/amethyst`;
4. добавляет команду `Amethyst` в `~/.local/bin` (и ссылку `amethyst`).

После установки из любого терминала и любого каталога:

```bash
Amethyst
```

Плеер запускается в том же окне терминала. Если `~/.local/bin` отсутствует в
`PATH`, установщик покажет строку для `~/.bashrc` или `~/.zshrc`.

Обновление: снова выполните `./install.sh` из папки проекта.

#### Arch Linux

```bash
sudo pacman -S mpv
```

#### Ручной запуск без установки

Если зависимости уже есть в системе:

```bash
python3 amethyst.py
```

### Вход в аккаунт (пункт меню 8)

#### 1. Автоматически из браузера

Войдите на <https://music.youtube.com> в Firefox или Chromium-подобном браузере,
затем выберите в меню:

```
8 → 1
```

Amethyst найдёт cookie, проверит вход read-only запросом к аккаунту и сохранит
заголовки для `ytmusicapi`. Сразу после входа плейлисты из библиотеки
импортируются автоматически и появятся в меню «7. Плейлисты».

#### 2. Вручную (как в Kanon)

Если автопоиск не сработал:

1. Откройте `music.youtube.com`, войдите в аккаунт.
2. F12 → Network → обновите страницу → выберите запрос `browse`.
3. ПКМ → Copy → **Copy request headers** (или **Copy as cURL**).
4. В меню выберите `8 → 2`, вставьте текст и завершите пустой строкой.

#### 3. OAuth (опционально)

Пункт `8 → 3`. Требует `client_id` и `client_secret` из Google Cloud Console.

### Управление в плеере

| Клавиша | Действие |
| --- | --- |
| `Space` | пауза / продолжить |
| `n` | следующий трек |
| `s` | остановить и выйти |
| `q` / `Esc` | выйти |
| `+` / `=` | громкость +5% |
| `-` / `_` | громкость −5% |
| `]` / `[` | громкость +1% / −1% |
| колесо мыши, `↑` / `↓` | громкость |
| `←` / `→` | перемотка на 5 секунд |

### Язык

Приоритет выбора языка:

1. переменная окружения `AMETHYST_LANG` (`ru` или `en`);
2. ключ `language` в `settings.json`;
3. системная локаль (`LC_ALL`, `LC_MESSAGES`, `LANG`);
4. английский.

Примеры:

```bash
AMETHYST_LANG=en Amethyst
AMETHYST_LANG=ru Amethyst
```

Язык также можно переключить во время работы: `10. Language / Язык`.

### Где хранятся данные

Код и пользовательские данные разделены. Cookie, OAuth-токены и плейлисты
лежат вне папки проекта:

```
Linux:   $XDG_CONFIG_HOME/amethyst   (~/.config/amethyst по умолчанию)
macOS:   ~/Library/Application Support/amethyst
Windows: %APPDATA%\amethyst
```

Путь можно переопределить переменной окружения `AMETHYST_DATA_DIR`.

| Файл | Назначение |
| --- | --- |
| `browser_auth.json` | cookie/заголовки аккаунта (права `600`) |
| `oauth.json` | OAuth-токен (если используется) |
| `oauth_client.json` | OAuth client id/secret (если используется) |
| `playlists.json` | локальные плейлисты |
| `account_playlists.json` | кеш списка плейлистов аккаунта |
| `settings.json` | язык интерфейса и другие настройки |

Старые данные из `~/.config/ytmusic-cli` переносятся автоматически при запуске.
Обновить список плейлистов аккаунта можно вручную: `7 → 7`. Треки
подгружаются из YouTube Music при открытии или воспроизведении плейлиста.

Чтобы включить случайный порядок без повторов, выберите в меню плейлистов
`7 → 8. Воспроизвести плейлист в случайном порядке (без повторов)`.

> **Важно:** `browser_auth.json` даёт доступ к аккаунту. Не публикуйте его и не
> коммитьте — он уже исключён в `.gitignore`.

### Удаление

```bash
./install.sh --uninstall          # удалить программу, данные сохранить
./install.sh --uninstall --purge  # удалить и данные аккаунта
```

### Структура проекта

```
amethyst/
├── amethyst.py               # весь плеер
├── install.sh                # установщик и удаление
├── requirements.txt          # зависимости Python
├── README.md
├── .gitignore
├── amethyst-src.zip          # исходники архивом
└── amethyst-src.tar.gz       # исходники архивом
```

### Ограничения

- Проект неофициальный и не связан с Google/YouTube.
- Нужны `mpv`, `yt-dlp`, `ytmusicapi` и рабочая сессия YouTube Music в браузере.
- Некоторые cookie Chromium зашифрованы системным ключом; для них используется
  `yt-dlp`, а при неудаче — ручная вставка заголовков.
